from PyQt5 import QtWidgets, QtGui, QtCore
from PyQt5.QtWidgets import *
from PyQt5.uic import loadUi
from webbrowser import open as op
import sys
import os

class RainItPy(QDialog):
    def __init__(self):
        super(RainItPy, self).__init__()
        loadUi("main.ui", self)
        self.Close.clicked.connect(self.onclose)
        self.mini.clicked.connect(self.onmini)
        self.saveas.clicked.connect(self.save_current_file)
        self.openas.clicked.connect(self.openfile)
        self.run.clicked.connect(self.onrun)
        self.search.clicked.connect(self.searchme)
        self.runtestbtn.clicked.connect(self.testrun)
        self.savebtn.clicked.connect(self.save)
    
    def save(self):
        with open(saveas[0], "w") as f:
            f.write(self.code.toPlainText())

    def testrun(self):
        exec(self.runtest1.toPlainText())

    def searchme(self):
        op(self.searchweb.text())

    def onrun(self):
        exec(self.code.toPlainText())
            
    def onmini(self):
        widget.showMinimized()
    
    def onclose(self):
        widget.destroy()
        
    def save_current_file(self):
        global saveas
        saveas = QFileDialog.getSaveFileName(parent=self, caption="Save file", directory=os.getcwd(), filter="Python files (*.py)", initialFilter='Python files (*.py)')
        with open(saveas[0], "w") as f:
            f.write(self.code.toPlainText())
    
    def openfile(self):
        global openas
        openas = QFileDialog.getOpenFileName(self, "Open file", os.getenv('HOME'))
        with open(openas[0], "r") as f:
            r = f.read()
            self.code.clear()
            self.code.setText(r)
        
if __name__ == "__main__":
    app = QApplication(sys.argv)
    run = RainItPy()
    widget = QStackedWidget()
    widget.addWidget(run)
    widget.setWindowTitle("RainItPy")
    widget.setWindowIcon(QtGui.QIcon("icon.ico"))
    widget.setWindowFlag(QtCore.Qt.FramelessWindowHint)
    widget.setAttribute(QtCore.Qt.WA_TranslucentBackground)
    widget.showMaximized()
    
    widget.show()
    
    sys.exit(app.exec())    